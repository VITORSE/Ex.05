exports.rgm = "25612158 "

exports.primeiro_nome = "Vitor"

exports.ultimo_nome = "Evangelista"