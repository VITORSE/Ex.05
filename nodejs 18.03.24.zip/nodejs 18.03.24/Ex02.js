var aluno = require("./basecod");
var http = require("http");

console.log(aluno.rgm)
console.log(aluno.primeiro_nome)
console.log(aluno.ultimo_nome)

http.createServer(function (req, res) {
    res.writeHead(200, {'Content-Type': 'text/html'});
    res.write(aluno.rgm);
    res.write(aluno.primeiro_nome);
    res.write(aluno.ultimo_nome);
    res.end();
}).listen(8000);